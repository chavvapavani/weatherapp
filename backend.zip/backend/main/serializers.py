from rest_framework import serializers

from main.models import Weather

# from backend.main.models import Weather

class WeatherLens(object):
    def __init__(self,weather_details):
        self.weather_details = weather_details
class WeatherAPiSerializer(serializers.Serializer):  
    city=serializers.CharField(max_length=60,required=True)  #initializing the city field
class OutputDataSerializer(serializers.Serializer):
    weather_details = serializers.DictField(child = serializers.CharField())
# class OutputDataSerializer(serializers.Serializer):
#     weather_details = WeatherDataSerializer()
class WeatherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Weather
        fields = (
            'city',
            'weather_condition',
            'temperature',
            'humidity',
            'pressure',
            'minimum_temp',
            'maximum_temp',
            'icon',
            'cod'

        )
# class Geeks(object):
#     def __init__(self, dictionary):
#         self.dictionary = dictionary
 
# # create a serializer
# class GeeksSerializer(serializers.Serializer):
#     # initialize fields
#     dictionary = serializers.DictField(child = serializers.CharField())
     



# >>> demo = {}
# >>> demo['name'] = "Naveen"
# >>> demo['age'] = 21

# # create a object of type Geeks
# >>> obj = Geeks(demo)

# # serialize the object
# >>> serializer = GeeksSerializer(obj)





# city = models.CharField(max_length=60,blank=False)
#     weather_condition = models.CharField(max_length=500)
#     temperature=models.FloatField()
#     humidity=models.FloatField()
#     pressure=models.FloatField()
#     minimum_temp=models.FloatField()
#     maximum_temp=models.FloatField()
#     icon=models.CharField(max_length=60)
#     cod=models.CharField(max_length=60)

# city = models.CharField(max_length = 60 , blank = False)
# weather_condition = models.CharField