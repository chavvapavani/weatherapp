from rest_framework.response import Response
import requests
from rest_framework import status
from rest_framework.views import APIView
from .models import Weather
from .serializers import WeatherAPiSerializer, WeatherLens, WeatherSerializer,OutputDataSerializer

def return_response_data(data: dict):
    """
    function which returns the response of the API call in common way as described below.

    """
    resp_data = {"data": data}
    return resp_data
class WeatherApi(APIView):#weather Api
    serializer_class=WeatherAPiSerializer
    serializer_class1=OutputDataSerializer
    def post(self,request): 
        import ipdb
        ipdb.set_trace()
        try:
            serializer=self.serializer_class(data=request.data)  #serializing the data
            serializer.is_valid(raise_exception=True)
            city=serializer.validated_data.get('city') #getting the city name as input by the user
            currentweatherurl=f"http://api.openweathermap.org/data/2.5/weather?q={city}&units=metric&APPID=b0b2a8c6eb68cf455d2b353ed0537b55"
            data=requests.get(currentweatherurl)   #requesting the given url for the data
            json_data=data.json()  #converting the data into json form
            #getting only required fields from json data
            if(city.isnumeric()):   #checking whether the city name contains numbers or not
                return Response({"cod":"405"})      #returing cod:405 if it contains numbers in the city name
            weather_data = {
                
                "weather_condition": json_data['weather'][0]['description'],
                "temperature": json_data['main']['temp'],
                "city": json_data['name'],
                "humidity":json_data['main']['humidity'],
                "pressure":json_data['main']['pressure'],
                "minimum_temp":json_data['main']['temp_min'],
                "maximum_temp":json_data['main']['temp_max'],
                "icon":json_data['weather'][0]['icon'],
                "cod":'200'  
                }
            
            # weathervar = Weather.objects.create(**weather_data['data'])
            obj=WeatherLens(weather_data)
            polling_response = return_response_data(obj)
            data_serializer=self.serializer_class1(polling_response)
            return Response(data_serializer.data)
            # data1=weather(weather_data)
            # serializer = WeatherSerializer(data1)
            # serializer.save()
        except:
            return Response({"cod":"404"})


class WeatherForecast(APIView): #forecastApi
    serializer_class=WeatherAPiSerializer
    def post(self,request):
        try: 
            serializer=self.serializer_class(data=request.data)
            serializer.is_valid(raise_exception=True)
            city=serializer.validated_data.get('city')#getting the city name as input by the user
            if(city.isnumeric()):   #checking whether the city name contains numbers or not
                return Response({"cod":405})
            forecasturl=f"http://api.openweathermap.org/data/2.5/forecast?q={city}&units=metric&APPID=b0b2a8c6eb68cf455d2b353ed0537b55"
            data=requests.get(forecasturl) #requesting the given url for the data
            json_data=data.json()#converting the data into json form
            date_list=[]
            forecast_data=[]#list to store output data
            for i in range(0,json_data['cnt']):
                date=json_data['list'][i]['dt_txt'].split(" ")[0]#getting date from the json_data
                if date not in date_list:
                    date_list.append(date)
                    each_date={}
                    each_date.update({"temperature":json_data['list'][i]['main']['temp']})
                    each_date.update({"description":json_data['list'][i]['weather'][0]['description']})
                    each_date.update({"icon":json_data['list'][i]['weather'][0]['icon']})
                    each_date.update({"date":date})               
                    forecast_data.append(each_date)
            forecast_data.append({"cod":200})            
            return Response(forecast_data)
        except:
            return Response({"cod":400})




    