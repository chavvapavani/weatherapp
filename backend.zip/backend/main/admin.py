from django.contrib import admin

from main.models import Weather

# Register your models here.
admin.site.register(Weather)